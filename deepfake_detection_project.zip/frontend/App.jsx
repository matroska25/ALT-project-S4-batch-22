import {useState} from "react";
import axios from "axios";

export default function App(){
 const [result,setResult]=useState(null);
 async function upload(e){
  const f=e.target.files[0];
  const fd=new FormData();
  fd.append("file",f);
  const r=await axios.post("http://localhost:8000/predict",fd);
  setResult(r.data);
 }
 return <div style={{fontFamily:"Arial",padding:40}}>
  <h1>DeepFake Detector</h1>
  <input type="file" onChange={upload}/>
  {result && <div><h2>{result.label}</h2><p>{result.confidence}% confidence</p></div>}
 </div>;
}
