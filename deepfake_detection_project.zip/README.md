# DeepFake Detection Project

A B.Tech-ready project using TensorFlow + EfficientNetB0, OpenCV, MTCNN and FastAPI.

## Features
- Video upload
- Face extraction
- EfficientNetB0 binary classifier
- Confidence score
- FastAPI backend
- React frontend scaffold

See backend/README.md for setup.
