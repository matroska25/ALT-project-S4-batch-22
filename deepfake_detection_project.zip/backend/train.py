import tensorflow as tf
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras import layers

IMG=(224,224)
train=tf.keras.preprocessing.image_dataset_from_directory("processed_faces",image_size=IMG,batch_size=32)

base=EfficientNetB0(weights="imagenet",include_top=False,input_shape=(224,224,3))
base.trainable=False

model=tf.keras.Sequential([
    base,
    layers.GlobalAveragePooling2D(),
    layers.Dense(256,activation="relu"),
    layers.Dropout(0.4),
    layers.Dense(1,activation="sigmoid")
])

model.compile(optimizer="adam",loss="binary_crossentropy",metrics=["accuracy"])
model.fit(train,epochs=10)
model.save("models/deepfake_detector.h5")
