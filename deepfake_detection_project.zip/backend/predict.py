import tensorflow as tf
import cv2
import numpy as np

model=tf.keras.models.load_model("models/deepfake_detector.h5")
img=cv2.imread("test.jpg")
img=cv2.resize(img,(224,224))/255.0
pred=float(model.predict(np.expand_dims(img,0),verbose=0)[0][0])
print("Fake" if pred>0.5 else "Real", pred)
