from fastapi import FastAPI, UploadFile, File
import tensorflow as tf
import numpy as np
import cv2
from PIL import Image
import io

app=FastAPI(title="DeepFake Detector")
model=tf.keras.models.load_model("models/deepfake_detector.h5",compile=False)

@app.post("/predict")
async def predict(file:UploadFile=File(...)):
    img=Image.open(io.BytesIO(await file.read())).convert("RGB")
    img=img.resize((224,224))
    arr=np.array(img)/255.0
    pred=float(model.predict(np.expand_dims(arr,0),verbose=0)[0][0])
    return {"label":"Fake" if pred>0.5 else "Real","confidence":round(max(pred,1-pred)*100,2)}
