## Backend

Install:
pip install -r requirements.txt

Train:
python train.py

Run API:
uvicorn app:app --reload
