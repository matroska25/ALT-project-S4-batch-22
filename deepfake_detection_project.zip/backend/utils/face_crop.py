from mtcnn import MTCNN
import cv2

det=MTCNN()

def crop_face(inp,out):
    img=cv2.imread(inp)
    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    faces=det.detect_faces(rgb)
    if not faces: return
    x,y,w,h=faces[0]["box"]
    face=cv2.resize(img[y:y+h,x:x+w],(224,224))
    cv2.imwrite(out,face)
