import cv2, os

def extract_frames(video,out,interval=10):
    os.makedirs(out,exist_ok=True)
    cap=cv2.VideoCapture(video)
    i=s=0
    while True:
        ret,frame=cap.read()
        if not ret: break
        if i%interval==0:
            cv2.imwrite(f"{out}/frame_{s}.jpg",frame)
            s+=1
        i+=1
    cap.release()
